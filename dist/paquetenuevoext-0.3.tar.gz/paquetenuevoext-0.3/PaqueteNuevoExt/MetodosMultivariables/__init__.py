from caminataAleatoria import caminata_aleatoria
from cauchy import cauchy
from fletcherReeves import fletcherReeves
from hookeJeeves import hooke_jeeves
from nelderMeadSimplex import nelder_mead
from newton import newton