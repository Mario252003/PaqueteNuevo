from biseccion import biseccion
from BusquedaDorada import busquedaDorada
from Fibonacci import fibonacci_search
from IntervalHalving import interval_halving_method
from NewtonRaph import newton_raphson
from Secante import secante